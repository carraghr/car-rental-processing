To run application from assessment folder location:
	java -jar target/Demo.jar